#!/system/bin/sh

if [ ! -d /system/etc/init.d ]; then
        echo "Create init.d directory" 
        /system/bin/mkdir /system/etc/init.d
        chown root.root /system/etc/init.d
fi

echo "Create the init script"
echo "#!/system/bin/sh" > /system/etc/init.d/00stop_ric
echo "" >> /system/etc/init.d/00stop_ric
echo "insmod /system/lib/modules/ric_mod.ko" >> /system/etc/init.d/00stop_ric
chown root.root /system/etc/init.d/00stop_ric
chmod 0755 /system/etc/init.d/00stop_ric

if [ -e /system/etc/init.qcom.post_boot.sh ]; then
	if grep "/system/xbin/busybox run-parts /system/etc/init.d" /system/etc/init.qcom.post_boot.sh > /dev/null; then
		:
	else
		echo "/system/xbin/busybox run-parts /system/etc/init.d" >> /system/etc/init.qcom.post_boot.sh
	fi
elif [ -e /system/etc/hw_config.sh ]; then
	if grep "/system/xbin/busybox run-parts /system/etc/init.d" /system/etc/hw_config.sh > /dev/null; then
		:
	else
		echo "/system/xbin/busybox run-parts /system/etc/init.d" >> /system/etc/hw_config.sh
	fi
fi

# Check for write access
if mkdir /system/rictest; then
    # Do nothing
    :
else
    echo "Can't write to system!" >&2
    exit 1;
fi

if [ -e /system/rictest ]; then
    rm -rf /system/rictest
fi


if [ ! -x /system/xbin/busybox ]; then
   echo "Copy busybox to system"
   cp /data/local/tmp/busybox /system/xbin/busybox
   chown root.shell /system/xbin/busybox
   chmod 0755 /system/xbin/busybox
   /system/xbin/busybox --install -s /system/xbin
fi

echo "Remove temp files"

if [ -e /system/lib/modules/wp_mod.ko ]; then
     rm /system/lib/modules/wp_mod.ko
fi

if [ -e /data/local/tmp/ric_mod.ko ]; then
     rm /data/local/tmp/ric_mod.ko
fi

if [ -e /data/local/tmp/copymodulecrc ]; then
     rm /data/local/tmp/copymodulecrc
fi

if [ -e /data/local/tmp/busybox ]; then
     rm /data/local/tmp/busybox
fi

echo "All done..."
exit 0;