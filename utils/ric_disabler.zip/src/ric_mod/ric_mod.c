/* ric_mod.c
 *
 * Hooking sony_ric_enabled() from Sony RIC Security Module.
 * Mount the file system as read/write.
 *
 */

#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/vmalloc.h>
#include <linux/kallsyms.h>
#include <linux/version.h>
#include <linux/slab.h>
#include <asm/mmu_writeable.h>

#define DRIVER_AUTHOR "alexj"
#define DRIVER_DESCRIPTION "Sony RIC disabler"
#define DRIVER_VERSION "0.1"

#define OPCODE_SIZE 12 /* ARM hook size is 12 bytes */

/*
 * On some old kernel releases the module failed to load properly when kmalloc() is called.
 *
 * define VMALLOCED for memory allocation by vmalloc().
 */
#if 0
#define VMALLOCED
#endif

struct hookdata_t
{
	void* paddr;
	unsigned char m_data[OPCODE_SIZE];
	unsigned char m_opcode[OPCODE_SIZE];
	struct list_head list;
};

LIST_HEAD(head_obj);

static unsigned long m_address;
static bool ric_enable=false; /* Current status - false if protection is enabled, true disabled. */


static int sony_ric_disabled(void)
{
	return 0;
}

inline void arm_poke ( void* p_addr, const char* p_data )
{
	unsigned long* m_target = (unsigned long*)p_addr;
	unsigned long* m_opcode = (unsigned long*)p_data;

	mem_text_write_kernel_word(m_target, *m_opcode);
	mem_text_write_kernel_word(m_target + 1, *(m_opcode + 1));
	mem_text_write_kernel_word(m_target + 2, *(m_opcode + 2));

}

/* Store the target function pointer, original code and new code to the linked list. */
static void ric_save ( void* p_addr,  const unsigned char* p_opcode, const unsigned char* p_data )
{
	struct hookdata_t* ps;

	if(p_addr!=NULL && p_opcode!=NULL && p_data!=NULL)
	{
		/* allocate the memory for the whole object */
		#ifdef VMALLOCED
		ps = vmalloc(sizeof(*ps));
		#else
		ps = kzalloc(sizeof(*ps), GFP_KERNEL);
		#endif
		if (!ps)
		{
			pr_err("unable to allocate memory\n");
			return;
		}

		ps->paddr = p_addr;
		memcpy(ps->m_data, p_data, OPCODE_SIZE);
		memcpy(ps->m_opcode, p_opcode, OPCODE_SIZE);
		#ifdef DEBUG
		pr_info("I got: %zu bytes of memory\n", ksize(ps));
		pr_info("%s: p_addr 0x%p\n", __func__, ps->paddr);
		print_hex_dump(KERN_DEBUG, "m_opcode ", DUMP_PREFIX_ADDRESS, 16, 1, ps->m_opcode, OPCODE_SIZE, true);
		print_hex_dump(KERN_DEBUG, "m_data ", DUMP_PREFIX_ADDRESS, 16, 1, ps->m_data, OPCODE_SIZE, true);
		#endif
		list_add(&ps->list, &head_obj);
	}
}

/* Construct shellcode and rewrite target */
static void ric_rewrite ( void* p_addr, void* p_data )
{
	unsigned char m_opcode[OPCODE_SIZE]= {0}; /* local buffer for new code */
	unsigned char m_data[OPCODE_SIZE]= {0};   /* local buffer to save original code */

	/* ldr pc, [pc, #0]; .long addr; .long addr */
	memcpy(m_opcode, "\x00\xf0\x9f\xe5\x00\x00\x00\x00\x00\x00\x00\x00", OPCODE_SIZE);
	*(unsigned long*)&(m_opcode)[4] = (unsigned long)p_data;
	*(unsigned long*)&(m_opcode)[8] = (unsigned long)p_data;

        #ifdef DEBUG
        pr_info("%s: hooking function 0x%p with 0x%p\n", __func__, p_addr, p_data);
        print_hex_dump(KERN_DEBUG, "p_addr ", DUMP_PREFIX_ADDRESS, 16, 1, p_addr, OPCODE_SIZE, true);
        print_hex_dump(KERN_DEBUG, "p_data ", DUMP_PREFIX_ADDRESS, 16, 1, p_data, OPCODE_SIZE, true);
        #endif

	memcpy(m_data, p_addr, OPCODE_SIZE); /* save target pointer */

	/* At this point all function calls to sony_ric_enabled() will redirect to sony_ric_disabled(). */
	arm_poke(p_addr, m_opcode);

	ric_save(p_addr, m_opcode, m_data);

}

/* Restore original opcodes. */
static void ric_restore ( void* p_addr )
{
	struct hookdata_t* ps;

	list_for_each_entry ( ps, &head_obj, list )
	if ( p_addr == ps->paddr )
	{
		arm_poke(p_addr, ps->m_data);
		ric_enable=!ric_enable;
		list_del( &ps->list);
		#ifdef VMALLOCED
		vfree(ps);
		#else
		kfree(ps);
		#endif
		break;
	}
}

static int __init ric_mod_init(void)
{

	m_address=kallsyms_lookup_name("sony_ric_enabled");
	if(m_address)
	{
		ric_rewrite((void*)m_address, &sony_ric_disabled);
		ric_enable=!ric_enable;
	}
	else
	{
		printk(KERN_ERR "[%s] Unable to loоckup sony_ric_enabled symbol\n", __this_module.name);
		return -1;
	}

	printk(KERN_INFO "[%s] module loaded\n", __this_module.name);
	printk(KERN_INFO "[%s] Sony RIC is now : %s\n", __this_module.name, ric_enable ?  "disabled" : "enabled");

	return 0;
}

static void __exit ric_mod_exit(void)
{

	if(ric_enable)
		ric_restore((void*)m_address);

	printk(KERN_INFO "[%s] module unloaded\n", __this_module.name);
	printk(KERN_INFO "[%s] Sony RIC is now : %s\n", __this_module.name, ric_enable ?  "disabled" : "enabled");

}

module_init(ric_mod_init);
module_exit(ric_mod_exit);

MODULE_DESCRIPTION(DRIVER_DESCRIPTION);
MODULE_VERSION(DRIVER_VERSION);
MODULE_LICENSE("GPL");
MODULE_AUTHOR(DRIVER_AUTHOR);

