#!/sbin/sh

if [ ! -d /system/etc/init.d ]; then
        echo "Create init.d directory" 
	mkdir /system/etc/init.d
        chown root.root /system/etc/init.d
        chmod 0755 /system/etc/init.d
fi

echo "Create the init script"
echo "#!/system/bin/sh" > /system/etc/init.d/00stop_ric
echo "" >> /system/etc/init.d/00stop_ric
echo "insmod /system/lib/modules/ric_mod.ko" >> /system/etc/init.d/00stop_ric
chown root.root /system/etc/init.d/00stop_ric
chmod 0755 /system/etc/init.d/00stop_ric

if [ -e /system/etc/init.qcom.post_boot.sh ]; then
	if grep "/system/xbin/busybox run-parts /system/etc/init.d" /system/etc/init.qcom.post_boot.sh > /dev/null; then
		:
	else
		echo "/system/xbin/busybox run-parts /system/etc/init.d" >> /system/etc/init.qcom.post_boot.sh
	fi
elif [ -e /system/etc/hw_config.sh ]; then
	if grep "/system/xbin/busybox run-parts /system/etc/init.d" /system/etc/hw_config.sh > /dev/null; then
		:
	else
		echo "/system/xbin/busybox run-parts /system/etc/init.d" >> /system/etc/hw_config.sh
	fi
fi

if [ ! -x /system/xbin/busybox ]; then
   echo "copy busybox to system"
   cp /tmp/busybox /system/xbin/busybox
   chown root.shell /system/xbin/busybox
   chmod 0755 /system/xbin/busybox
   /system/xbin/busybox --install -s /system/xbin
fi

echo "All done..."
